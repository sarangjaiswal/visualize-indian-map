CREATE TRIGGER "rtree_gadm36_IND_1_geom_delete" AFTER DELETE ON "gadm36_IND_1" WHEN old."geom" NOT NULL BEGIN DELETE FROM "rtree_gadm36_IND_1_geom" WHERE id = OLD."fid"; END;

