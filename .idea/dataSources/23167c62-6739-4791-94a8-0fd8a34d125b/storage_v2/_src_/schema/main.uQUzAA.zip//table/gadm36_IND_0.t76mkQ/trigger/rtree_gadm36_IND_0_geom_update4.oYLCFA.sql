CREATE TRIGGER "rtree_gadm36_IND_0_geom_update4" AFTER UPDATE ON "gadm36_IND_0" WHEN OLD."fid" != NEW."fid" AND (NEW."geom" ISNULL OR ST_IsEmpty(NEW."geom")) BEGIN DELETE FROM "rtree_gadm36_IND_0_geom" WHERE id IN (OLD."fid", NEW."fid"); END;

