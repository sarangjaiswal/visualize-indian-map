CREATE TRIGGER "rtree_gadm36_IND_3_geom_delete" AFTER DELETE ON "gadm36_IND_3" WHEN old."geom" NOT NULL BEGIN DELETE FROM "rtree_gadm36_IND_3_geom" WHERE id = OLD."fid"; END;

