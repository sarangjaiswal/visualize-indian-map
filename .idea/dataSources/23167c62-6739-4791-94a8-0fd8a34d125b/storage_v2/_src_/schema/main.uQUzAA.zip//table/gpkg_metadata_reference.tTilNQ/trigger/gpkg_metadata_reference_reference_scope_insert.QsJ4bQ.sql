CREATE TRIGGER 'gpkg_metadata_reference_reference_scope_insert' BEFORE INSERT ON 'gpkg_metadata_reference' FOR EACH ROW BEGIN SELECT RAISE(ABORT, 'insert on table gpkg_metadata_reference violates constraint: reference_scope must be one of "geopackage", table", "column", "row", "row/col"') WHERE NOT NEW.reference_scope IN ('geopackage','table','column','row','row/col'); END;

