CREATE TRIGGER "rtree_gadm36_IND_2_geom_delete" AFTER DELETE ON "gadm36_IND_2" WHEN old."geom" NOT NULL BEGIN DELETE FROM "rtree_gadm36_IND_2_geom" WHERE id = OLD."fid"; END;

