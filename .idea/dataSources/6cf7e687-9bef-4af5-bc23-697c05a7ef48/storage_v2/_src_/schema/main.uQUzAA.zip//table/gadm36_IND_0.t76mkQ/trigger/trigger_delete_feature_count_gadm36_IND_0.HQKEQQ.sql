CREATE TRIGGER "trigger_delete_feature_count_gadm36_IND_0" AFTER DELETE ON "gadm36_IND_0" BEGIN UPDATE gpkg_ogr_contents SET feature_count = feature_count - 1 WHERE lower(table_name) = lower('gadm36_IND_0'); END;

